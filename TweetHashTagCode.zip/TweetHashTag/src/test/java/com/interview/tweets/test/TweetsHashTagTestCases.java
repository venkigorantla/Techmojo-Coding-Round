package com.interview.tweets.test;

import org.junit.Test;

import com.interview.tweets.driver.TweetsHashTagCountDriver;
import com.interview.tweets.entities.ITweetsHashTag;
import com.interview.tweets.entities.TweetHashTagsFactory;
import com.interview.tweets.entities.TweetsHashTagCountReq;
import com.interview.tweets.store.TweetsStore;
import com.interview.tweets.utils.TweetHashTagUtils;

import org.junit.Ignore;
import static org.junit.Assert.assertEquals;

import java.util.List;

public class TweetsHashTagTestCases {

	TweetsHashTagCountDriver messageUtil = new TweetsHashTagCountDriver();

	@Test
	public void testTweetExtraction() throws Exception {
		String tweet = "Worlds best cricketer is #sachin";
		String extractedTweet = TweetHashTagUtils.collectHashTag(tweet);
		assertEquals(null, extractedTweet, "#sachin");

	}

	@Test
	public void testHashTagCount() throws Exception {

		TweetsStore store = new TweetsStore();
		store.addHashTag("#test");
		store.addHashTag("#test1");
		store.addHashTag("#test2");
		store.addHashTag("#test");
		store.addHashTag("#test");

		TweetsHashTagCountReq req = new TweetsHashTagCountReq();
		req.setValue(3);
		req.setOp("TOPK"); 

		TweetHashTagsFactory tweetFact = new TweetHashTagsFactory();
		ITweetsHashTag tweetHashTag = tweetFact.getTweetsHashTag(req.getOp());
		List<String> topKTweets = tweetHashTag.getTweetsHashTags(store, req);
		assertEquals(null, "[#test, #test2, #test1]", topKTweets.toString());
		
	}
}