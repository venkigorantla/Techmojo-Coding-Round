package com.interview.tweets.test;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class TweetHashTag extends TestCase {
	/**
	 * Create the test case
	 *
	 * @param testName name of the test case
	 */
	
	public TweetHashTag(String testName) {
		super(testName);
	}

	/**
	 * @return the suite of tests being tested
	 */
	public static Test suite() {
		return new TestSuite(TweetHashTag.class, TweetsHashTagTestCases.class);
	}

	/**
	 * Rigourous Test :-)
	 */
	public void testApp() {
		assertTrue(true);
	}

}
