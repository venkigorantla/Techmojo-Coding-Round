package com.interview.tweets.entities;

/**
 * This is a request class to get count
 * @author Venkata Rao Gorantla
 *
 */
public class TweetsHashTagCountReq {

	private int value = 10;
	private String op = "TOPK";

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public String getOp() {
		return op;
	}

	public void setOp(String op) {
		this.op = op;
	}

}
