package com.interview.tweets.store;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * This class acts as tweets store which internally uses
 * HashMap to store data.
 * @author Venkata Rao Gorantla
 *
 */
public class TweetsStore {
	
	Map<String, Integer> tweetsStore;
	public TweetsStore() {
		tweetsStore = new HashMap<> ();
	}
	public void addHashTag(String hashTag) {
		Integer re = tweetsStore.get(hashTag);
		if(re == null) {
			tweetsStore.put(hashTag,1);
		} else {
			tweetsStore.put(hashTag,re+1);
		}
	}
	
	public int getHashTagCount(String hashTag) {
		return tweetsStore.get(hashTag);
	}
	public Map<String, Integer> getAllHashTags() {
		return tweetsStore;
		
	}
	

}
