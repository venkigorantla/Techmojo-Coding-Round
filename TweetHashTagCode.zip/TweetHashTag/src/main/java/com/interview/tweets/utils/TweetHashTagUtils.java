package com.interview.tweets.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.interview.tweets.store.TweetsStore;

/**
 * This class contains all Utility methods.
 * 
 * @author Venkata Rao Gorantla
 *
 */
public class TweetHashTagUtils {

	public static final String REG_EX_TAG = "(#[A-Za-z0-9-_]+)(?:#[A-Za-z0-9-_]+)*\\b";

	/**
	 * This method is to read the tweets from console and extract Hashtag from tweet
	 * and store in Tweet store.
	 * 
	 * @param store
	 * @throws Exception
	 */
	public static void readTweetsAndStore(TweetsStore store) throws Exception {

		// Read the data
		try {
			System.out.println("Enter noOf Tweets...");
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			int noOfTweets = Integer.valueOf(br.readLine());

			for (int i = 0; i < noOfTweets; ++i) {
				System.out.println("Enter Tweet String...");
				String tweet = br.readLine();
				String hashTag = collectHashTag(tweet);
				if(hashTag != null) {
					store.addHashTag(hashTag);
				}
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
			throw e;
		} catch (Exception e) {
			System.out.println(e.getMessage());
			throw e;
		}

	}

	/**
	 * Function is used to collect HashTag from tweet and return it.
	 * 
	 * @param tweet
	 * @return
	 */
	public static String collectHashTag(String tweet) {
		//Pattern hashTagMatcher = Pattern.compile("(#[A-Za-z0-9-_]+)(?:#[A-Za-z0-9-_]+)*\\b");
		Pattern hashTagMatcher = Pattern.compile(REG_EX_TAG);
		Matcher hashTagMatch = hashTagMatcher.matcher(tweet);
		if (hashTagMatch.find())
			return hashTagMatch.group(1);

		return null;
	}

}
