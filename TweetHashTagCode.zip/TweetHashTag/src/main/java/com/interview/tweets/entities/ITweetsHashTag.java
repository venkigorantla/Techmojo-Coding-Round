package com.interview.tweets.entities;

import java.util.List;
import com.interview.tweets.store.TweetsStore;

/**
 * Interface to get TweetHashTags.
 * This interface is useful in case of TOPK,
 * BottomK, etc.
 * 
 * @author Venkata Rao Gorantla
 *
 */
public interface ITweetsHashTag {

	public List<String> getTweetsHashTags(TweetsStore store, TweetsHashTagCountReq req);
}
