package com.interview.tweets.driver;

import java.util.List;

import com.interview.tweets.entities.ITweetsHashTag;
import com.interview.tweets.entities.TweetHashTagsFactory;
import com.interview.tweets.entities.TweetsHashTagCountReq;
import com.interview.tweets.store.TweetsStore;
import com.interview.tweets.utils.TweetHashTagUtils;

/**
 * Driver class
 * 
 * @author Venkata Rao Gorantla
 *
 */
public class TweetsHashTagCountDriver {

	public static void main(String[] args) throws Exception {
		TweetsStore store = new TweetsStore();
		TweetHashTagUtils.readTweetsAndStore(store);

		// Get TopK tweets

		// Req
		TweetsHashTagCountReq req = new TweetsHashTagCountReq();
		if (args.length != 0) {
			if (args.length <= 2) {
				System.out.println("Usage:");
				System.out.println(
						"java -jar TweetHashTag-0.0.1-SNAPSHOT-jar-with-dependencies.jar <1/2/3/validNumber> <TOPK>");
				return;
			}
			if (args[0] != null) {
				req.setValue(Integer.valueOf(args[0]));
			}
			if (args[1] != null) {
				req.setOp(args[1]);
			}
		}

		// End of Request

		TweetHashTagsFactory tweetFact = new TweetHashTagsFactory();
		ITweetsHashTag tweetHashTag = tweetFact.getTweetsHashTag(req.getOp());
		List<String> topKTweets = tweetHashTag.getTweetsHashTags(store, req);

		System.out.println(req.getOp() + "Tweets are :  " + topKTweets);
	}

}
