package com.interview.tweets.entities;

/**
 * Factory to return TOPK or BOTTOMK implementation
 * based on operation.
 * @author Venkata Rao Gorantla
 *
 */
public class TweetHashTagsFactory {
	
	ITweetsHashTag tweetsHashTag;
	
	public ITweetsHashTag getTweetsHashTag(String operation) {
		
		switch(operation) {
		
		case "TOPK":
			tweetsHashTag = new TopKTweetHashTag();
			break;
		//case "BOTTOMK":
		
		default:
			System.out.println("You have provided: " + operation +".Provide valid operation.."
					+ "Valid operations are TOPK etc.");
		
		}
		return tweetsHashTag;
	}
}
