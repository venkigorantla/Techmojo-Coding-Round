package com.interview.tweets.entities;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.interview.tweets.store.TweetsStore;

/**
 * This class is a specific implementation for TOPK
 * @author Venkata Rao Gorantla
 *
 */
public class TopKTweetHashTag implements ITweetsHashTag {

	@Override
	public List<String> getTweetsHashTags(TweetsStore store, TweetsHashTagCountReq req) {
		Map<String, Integer> tweets = store.getAllHashTags();

		// Sort the tweets by value
		List<Entry<String, Integer>> entries = sortTweetsByCount(tweets);

		// prepare results & return
		return prepareResult(req, entries);
	}

	/**
	 * Function is to prepare and return results. 
	 * @param req
	 * @param entries
	 * @return
	 */
	private List<String> prepareResult(TweetsHashTagCountReq req, List<Entry<String, Integer>> entries) {
		List<String> result = new ArrayList<>();
		for (int i = 0; i < req.getValue() && i < entries.size(); ++i) {
			result.add(entries.get(i).getKey());
		}
		return result;
	}

	/**
	 * Function is to sort the tweets by count value.
	 * @param tweets
	 * @return
	 */
	private List<Entry<String, Integer>> sortTweetsByCount(Map<String, Integer> tweets) {
		List<Entry<String, Integer>> entries = new ArrayList<>(tweets.entrySet());
		Collections.sort(entries, new Comparator<Entry<String, Integer>>() {

			@Override
			public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2) {
				return o2.getValue().compareTo(o1.getValue());
			}

		});
		return entries;
	}

}
